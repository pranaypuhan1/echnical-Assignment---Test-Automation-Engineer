package com.volvocars.code.test;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Master_Script {
	
	static WebDriver driver;
	
	static {
		
		System.setProperty("webdriver.chrome.driver","C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		
		}
	
	public static void main(String[] args) 
	
		
	{
			
	// Application Login-Volvo Cars
		Login ObjLogin = new Login();
		ObjLogin.userLogin();
		
	// Verify HomePage 
		Homepage ObjHomepage = new Homepage();
		ObjHomepage.pageDetails();	
		
	// Verify ListMenu Item
		Menu ObjMenu = new Menu();
		ObjMenu.menuList();
	
		
	// Verify Car Types 
		OurCars ObjOurCars = new OurCars();
		ObjOurCars.carType();
	
	// Verify Logout
		Logout ObjLogout = new Logout();
		ObjLogout.logout();

	}
	
	
	
}
