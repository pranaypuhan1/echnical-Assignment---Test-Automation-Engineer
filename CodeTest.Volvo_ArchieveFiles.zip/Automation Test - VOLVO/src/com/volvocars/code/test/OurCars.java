package com.volvocars.code.test;


import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


public class OurCars {
	
	
	public void carType()
	{
		WebDriver driver = Master_Script.driver;
		driver.findElement(By.id("sitenav:topbar:cars")).click();
						
		WebElement x = driver.findElement(By.xpath("/html/body/div[2]/nav/div[2]/div/div/div[1]/div/div[1]/div/div/div/div[1]/div"));
		
		// "Test" has been added to the item list to verify the negative scenario
		List<String> itemsToCheck = Arrays.asList("Electric","Hybrids","Mild hybrids","Test");
		System.out.println("No.of Cartypes for Test: "+itemsToCheck.size());
		
		
		for( int i = 0;i<itemsToCheck.size();i++)
			
		{
			if(x.getText().contains(itemsToCheck.get(i)))
			{
				System.out.println("Validation Success for CarType: "+itemsToCheck.get(i));
			}
			else
			{
				System.out.println("Validation Failed for CarType: "+itemsToCheck.get(i));
			}
			
		}
			
		
		driver.findElement(By.xpath("/html/body/div[2]/nav/div[2]/div/div/div[1]/div/div[2]")).click();
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		
		
		
		
	}

}
	
	
	
	
	


