package com.volvocars.code.test;

//import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;



public class Menu {

	//WebDriver driver;
	public void menuList()
	
			
		{
		
		WebDriver driver = Master_Script.driver;
			
			driver.findElement(By.id("sitenav-sidenav-toggle")).click();
			
			WebElement x = driver.findElement(By.xpath("/html/body/div[2]/nav/div[2]/div/div/div[2]/nav/div[2]/div[2]/div/div/div[1]/div[2]"));
			List<WebElement> y = x.findElements(By.xpath("./child::*"));
			System.out.println("No.of Sub-Menu Items: "+y.size());
			
			// Below list can be modified to check the negative scenarios(e.g: Replace "More" with "Test");
			List<String> itemsToCheck = Arrays.asList("Buy","Own","About Volvo","Explore","More");
			
			for(WebElement w:y)
			{
								
				if (itemsToCheck.contains(w.getText()))
					
				{
					System.out.println("Sub-Menu Item found: "+w.getText());
				}
				
				else
				{
					System.out.println("Sub-Menu Item not found: "+w.getText());
				}
				
			}
			
			driver.findElement(By.xpath("/html/body/div[2]/nav/div[2]/div/div/div[2]/nav/div[2]/div[1]/div[2]")).click();
			
		}
	
	
	
	
}
