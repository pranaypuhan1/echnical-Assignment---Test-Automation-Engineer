package com.volvocars.code.test;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class Homepage {

	public void pageDetails()
	{
		WebDriver driver = Master_Script.driver;
		// Validate Home page Content - Logo
		
		boolean Logo = driver.findElement(By.xpath("/html/body/div[2]/nav/div[3]/div/div[2]/nav/div[1]/a")).isDisplayed();
		if(Logo == true)
			{
				System.out.println("Logo validation Succefull");
			}
		else
			{
				System.out.println("Logo validation Not Succefull");
			}
	
		
	
	
	}
	
			
}
