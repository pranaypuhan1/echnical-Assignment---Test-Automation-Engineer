package com.volvocars.code.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Logout {
	
	public void logout()
	{
		WebDriver driver = Master_Script.driver;
		
		driver.close();
	}
	
	

}
