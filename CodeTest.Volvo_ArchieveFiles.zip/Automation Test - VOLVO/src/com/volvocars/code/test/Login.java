package com.volvocars.code.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class Login {
	
		
	public void userLogin(){
		
		WebDriver driver = Master_Script.driver;
					
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
			
			driver.get("https://www.volvocars.com/intl/v/car-safety/a-million-more");
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			String PageName = "A million more | Volvo Cars";
					

			if(driver.getTitle().toLowerCase().contains(PageName.toLowerCase()))
				{
					System.out.println("Validation Success");
				}
			else
				{
					System.out.println("Validation Failed: "+driver.getTitle()+" Page Opened" );
				}
		
			
			
		try{
			driver.findElement(By.xpath("/html/body/div[2]/nav/div[3]/div/div[2]/nav/div[3]")).click();
			driver.findElement(By.xpath("/html/body/div[2]/nav/div[2]/div/div/div[1]/div/div[2]")).click();
			System.out.println("Inside Try block");
			}
		catch (Exception e)
			{
			System.out.println("I am inside Catch Block");
			driver.findElement(By.id("onetrust-accept-btn-handler")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			}
	}

}
